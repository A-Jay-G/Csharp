﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Lab5;

namespace Lab7
{
    class basictool
    {
        public static void Pause()//pause function
        {
            Console.WriteLine("\n\nPress Any key to continue");
            Console.ReadKey();
        }
    }
}
