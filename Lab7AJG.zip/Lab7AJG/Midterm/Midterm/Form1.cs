﻿using Lab7;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Lab5_validation;
using System.Data.SqlClient;

namespace Lab7
{
    
    public partial class Form1: Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        
        public Form1(int intPerson_ID)
        {
            InitializeComponent();  //Creates and init's all form objects

            //Gather info about this one person and store it in a datareader
            PersonV2 temp = new PersonV2();
            SqlDataReader dr = temp.FindOnePerson(intPerson_ID);

            //Use that info to fill out the form
            //Loop thru the records stored in the reader 1 record at a time
            // Note that since this is based on one person's ID, then we
            //  should only have one record
            while (dr.Read())
            {
                //Take the Name(s) from the datareader and copy them
                // into the appropriate text fields
                txtfname.Text = dr["FirstName"].ToString();
                txtmname.Text = dr["MiddleName"].ToString();
                txtlname.Text = dr["LastName"].ToString();
                txtsrt1.Text = dr["Street1"].ToString();
                txtsrt2.Text = dr["Street2"].ToString();
                txtcity.Text = dr["City"].ToString();
                txtstate.Text = dr["State"].ToString();
                txtzip.Text = dr["Zipcode"].ToString();
                txtphone.Text = dr["Phone"].ToString();
                txtemail.Text = dr["Email"].ToString();
                txtcell.Text = dr["Cell"].ToString();
                txtUrl.Text = dr["Instagram"].ToString();

                lblPersonID.Text = dr["Person_ID"].ToString();
            }


        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            PersonV2 temp = new PersonV2();


                temp.FirstName = txtfname.Text;
                temp.MiddleName = txtmname.Text;
                temp.LastName = txtlname.Text;
                temp.Street1 = txtsrt1.Text;
                temp.Street2 = txtsrt2.Text;
                temp.State = txtstate.Text;
                temp.City = txtcity.Text;
                temp.Zip = txtzip.Text;
                temp.Phone = txtphone.Text;   
                temp.Email = txtemail.Text;
                temp.Cell = txtcell.Text;
                temp.Instaurl = txtUrl.Text;
                


            if (!temp.Feedback.Contains("ERROR:"))
            {
                Feedback.Text = temp.AddARecord();
                
            }
            else
            {

                Feedback.Text = temp.Feedback;
                /*temp.Feedback = ("Fullname: " + temp.FirstName + "  " + temp.MiddleName + "  " + temp.LastName + "\t" +
                                 "\nAddress: " + temp.Street1 + " \t" + temp.Street2 + " " + temp.City + " " + temp.State + "\t" +
                                 "\nPhone: " + temp.Phone + "\t" +
                                 "\nEmail: " + temp.Email+
                                 "\nCellphone:"+ temp.Cell+
                                 "\nInstagram URL:" +temp.Instaurl);
                Feedback.Text = temp.Feedback;*/
            }

        }

    private void btnView_Click(object sender, EventArgs e)
       {

       }

        private void txtfname_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnAdd_Click_1(object sender, EventArgs e)
        {

        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void txtcell_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtphone_TextChanged(object sender, EventArgs e)
        {

        }

        private void label13_Click(object sender, EventArgs e)
        {

        }
    }
}
