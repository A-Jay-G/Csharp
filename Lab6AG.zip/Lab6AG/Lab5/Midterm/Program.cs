﻿//Allen J. Gawlowicz
using Lab5_validation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Lab5;


namespace Lab5
{
    public class Person//class(add the variables to class of public) as private
    {
        bool blnResult;
        private string firstName;
        private string middleName;
        private string lastName;
        private string street1;
        private string street2;
        private string city;
        private string state;
        private string zip;
        private string phone;
        private string email;
        public string feedback = "";

        int min;

        public string FirstName
        {//creating public variable based on the private variables      
            get
            {
                return firstName;//return value of the private variables 
            }
            set
            {
                if (ValidationLibrary.IsItFilledIn(value))
                {
                    firstName = value;

                    //asssigning value of the public string to the private
                }
                else
                {
                    feedback += "\n\nERROR: Enter First Name!!  ";
                }
            }
        }
        public string MiddleName
        {
            get
            {
                return middleName;
            }
            set
            {
                if (ValidationLibrary.IsItFilledIn(value))
                {
                    middleName = value;

                }
                else
                {
                    feedback += "\n\nERROR: Enter Middle Name!!  ";

                }
            }
        }
        public string LastName
        {
            get
            {
                return lastName;
            }
            set
            {
                if (ValidationLibrary.IsItFilledIn(value))
                {
                    lastName = value;

                }
                else
                {
                    feedback += "\n\nERROR: Enter Last Name!!   ";
                }
            }

        }
        public string Street1
        {
            get
            {
                return street1;
            }
            set
            {
                if (ValidationLibrary.IsItFilledIn(value))
                {
                    street1 = value;
                }
                else
                {
                    feedback += "\n\nERROR:Enter street\n  ";
                }
            }
        }
        public string Street2
        {
            get
            {
                return street2;
            }
            set
            {
                street2 = value;
            }

        }
       
        public string Zip
        {
            get
            {
                
                return zip;
            }
            set
            {
                min = 5;
                if (ValidationLibrary.IsMinimumAmount(value, min))//validate the length of the zip if it is == 5;
                {
                    
                    do
                    {
                        zip = value;
                    } while (blnResult == true);
                }
                else
                {
                    feedback += "\n\nERROR:Enter Valid Zipcode  ";
                }

            }
        }
        public string City
        {
            get
            {
                return city;
            }
            set
            {
                if (ValidationLibrary.IsItFilledIn(value))
                {
                    city = value;
                }
            }
        }
        public string State
        {
            get
            {
                return state;
            }
            set
            {
                min = 2;
                if ((ValidationLibrary.Goodchar(value))&&(ValidationLibrary.IsMinimumAmount(value,min)))
                {
                    state = value;
                }
                else
                {
                    feedback += "\n\nERROR:Enter Valid State\n  ";
                }

            }
        }
        public string Phone
        {
            get
            {
              
                return phone;
            }
            set
            {
                min = 10;
                if (ValidationLibrary.IsMinimumAmount(value, min))
                {
                    
                    do
                    {
                        phone = value;
                    } while (blnResult == true);
                }
                else
                {
                    feedback += "\n\nERROR:Enter Valid Phone Number!!";
                }

            }
        }
        public string Email
        {
            get
            {
                return email;
            }
            set
            {
                if (ValidationLibrary.IsValidEmail(value))
                {
                    email = value;
                }
                else
                {
                    feedback += "\n\nERROR:Enter valid email";
                }
            }
        }
        public string Feedback
        {
            get
            {
                return feedback;

            }
            set
            {
                if (feedback.Contains("ERROR:"))
                {
                    feedback += "";
                }
                else
                {
                    feedback = value;
                }

            }
        }
        public Person()
        {
            firstName = "";
            middleName = "";
            lastName = "";
            street1 = "";
            street2 = "";
            city = "";
            state = "";
            zip = "";
            phone = "";
            email = "";
            feedback = "";

        }

        static class Program
        {
            /// <summary>
            /// The main entry point for the application.
            /// </summary>
            [STAThread]
            static void Main()
            {

                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);
                Application.Run(new Form1());

                Person temp = new Person();

                //User data inputs 

            }
        }
    }
}

    

