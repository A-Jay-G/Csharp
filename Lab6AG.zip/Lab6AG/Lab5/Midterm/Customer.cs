﻿//Allen J. Gawlowicz
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Lab5_validation;

namespace Lab5
{
    class Customer : PersonV2//Inherits PersonV2 class
    {
        private DateTime customerSince;
        private Double totalPurchases;
        bool discountMember;
        int rewardsEarned;
        public DateTime CustomerSince//New property in the PersonV2
        {
            get
            {
                return customerSince;
            }
            set
            {
                
                if (!ValidationLibrary.IsAFutureDate(value))
                {
                    customerSince = value;
                
                }
                else
                {
                    feedback += "\n\nERROR:Enter Valid Date! ";
                }
            }
        }
        public Double TotalPurchases
        {
            get
            {
                return totalPurchases;
            }
            set
            {
                //if (ValidationLibrary.IsItFilledIn(string temp);
                //{
                    totalPurchases = value;
                //}
                //else
                //{
                 //   feedback += "\n\nERROR:Enter valid Number!  ";
                //}
            }
        }
        public bool DiscountMember
        {
            get
            {
                return discountMember;
            }
            set
            { 

                discountMember = value;

            }
        }

        public int RewardsEarned
        {
            get
            {
                return rewardsEarned;
            }
            set
            {

                rewardsEarned = value;

            }
        }
        public Customer() : base()//add the property to the Base ;Person
        {
            rewardsEarned = 0;
            discountMember = false;
            totalPurchases = 0;
            //DateTime (customerSince);
        }
    }
}