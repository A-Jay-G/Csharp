﻿namespace Lab5
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.txtfname = new System.Windows.Forms.TextBox();
            this.txtsrt2 = new System.Windows.Forms.TextBox();
            this.txtemail = new System.Windows.Forms.TextBox();
            this.txtphone = new System.Windows.Forms.TextBox();
            this.txtzip = new System.Windows.Forms.TextBox();
            this.txtcity = new System.Windows.Forms.TextBox();
            this.txtlname = new System.Windows.Forms.TextBox();
            this.txtstate = new System.Windows.Forms.TextBox();
            this.txtsrt1 = new System.Windows.Forms.TextBox();
            this.txtmname = new System.Windows.Forms.TextBox();
            this.btnAdd = new System.Windows.Forms.Button();
            this.Feedback = new System.Windows.Forms.TextBox();
            this.lblfeed2 = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.txtcell = new System.Windows.Forms.TextBox();
            this.txtUrl = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(25, 14);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(86, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "First Name";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(25, 53);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(99, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "Middle name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(25, 96);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(86, 20);
            this.label3.TabIndex = 2;
            this.label3.Text = "Last Name";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(242, 20);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(66, 20);
            this.label4.TabIndex = 3;
            this.label4.Text = "Street 1";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(243, 46);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(66, 20);
            this.label5.TabIndex = 4;
            this.label5.Text = "Street 2";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(243, 115);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(48, 20);
            this.label6.TabIndex = 5;
            this.label6.Text = "State";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(25, 131);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(115, 20);
            this.label7.TabIndex = 6;
            this.label7.Text = "Phone Number";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(243, 86);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(35, 20);
            this.label8.TabIndex = 7;
            this.label8.Text = "City";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(466, 83);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(111, 20);
            this.label9.TabIndex = 8;
            this.label9.Text = "Email Address";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(243, 147);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(70, 20);
            this.label10.TabIndex = 9;
            this.label10.Text = "Zip code";
            this.label10.Click += new System.EventHandler(this.label10_Click);
            // 
            // txtfname
            // 
            this.txtfname.Location = new System.Drawing.Point(109, 14);
            this.txtfname.Name = "txtfname";
            this.txtfname.Size = new System.Drawing.Size(100, 26);
            this.txtfname.TabIndex = 10;
            this.txtfname.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // txtsrt2
            // 
            this.txtsrt2.Location = new System.Drawing.Point(315, 46);
            this.txtsrt2.Name = "txtsrt2";
            this.txtsrt2.Size = new System.Drawing.Size(124, 26);
            this.txtsrt2.TabIndex = 11;
            this.txtsrt2.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // txtemail
            // 
            this.txtemail.Location = new System.Drawing.Point(580, 83);
            this.txtemail.MaxLength = 20;
            this.txtemail.Name = "txtemail";
            this.txtemail.Size = new System.Drawing.Size(100, 26);
            this.txtemail.TabIndex = 12;
            // 
            // txtphone
            // 
            this.txtphone.Location = new System.Drawing.Point(137, 128);
            this.txtphone.MaxLength = 10;
            this.txtphone.Name = "txtphone";
            this.txtphone.Size = new System.Drawing.Size(100, 26);
            this.txtphone.TabIndex = 13;
            this.txtphone.TextChanged += new System.EventHandler(this.txtphone_TextChanged);
            // 
            // txtzip
            // 
            this.txtzip.Location = new System.Drawing.Point(319, 150);
            this.txtzip.MaxLength = 5;
            this.txtzip.Name = "txtzip";
            this.txtzip.Size = new System.Drawing.Size(100, 26);
            this.txtzip.TabIndex = 14;
            // 
            // txtcity
            // 
            this.txtcity.Location = new System.Drawing.Point(284, 86);
            this.txtcity.Name = "txtcity";
            this.txtcity.Size = new System.Drawing.Size(100, 26);
            this.txtcity.TabIndex = 15;
            this.txtcity.TextChanged += new System.EventHandler(this.textBox6_TextChanged);
            // 
            // txtlname
            // 
            this.txtlname.Location = new System.Drawing.Point(117, 96);
            this.txtlname.Name = "txtlname";
            this.txtlname.Size = new System.Drawing.Size(100, 26);
            this.txtlname.TabIndex = 16;
            // 
            // txtstate
            // 
            this.txtstate.Location = new System.Drawing.Point(297, 118);
            this.txtstate.MaxLength = 2;
            this.txtstate.Name = "txtstate";
            this.txtstate.Size = new System.Drawing.Size(55, 26);
            this.txtstate.TabIndex = 17;
            // 
            // txtsrt1
            // 
            this.txtsrt1.AcceptsTab = true;
            this.txtsrt1.Location = new System.Drawing.Point(315, 14);
            this.txtsrt1.Name = "txtsrt1";
            this.txtsrt1.Size = new System.Drawing.Size(132, 26);
            this.txtsrt1.TabIndex = 18;
            // 
            // txtmname
            // 
            this.txtmname.Location = new System.Drawing.Point(123, 53);
            this.txtmname.Name = "txtmname";
            this.txtmname.Size = new System.Drawing.Size(100, 26);
            this.txtmname.TabIndex = 19;
            // 
            // btnAdd
            // 
            this.btnAdd.AutoSize = true;
            this.btnAdd.Location = new System.Drawing.Point(28, 170);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(80, 39);
            this.btnAdd.TabIndex = 20;
            this.btnAdd.Text = "Submit";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click_1);
            // 
            // Feedback
            // 
            this.Feedback.AcceptsTab = true;
            this.Feedback.AccessibleRole = System.Windows.Forms.AccessibleRole.Row;
            this.Feedback.AllowDrop = true;
            this.Feedback.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Append;
            this.Feedback.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Feedback.HideSelection = false;
            this.Feedback.Location = new System.Drawing.Point(456, 153);
            this.Feedback.Multiline = true;
            this.Feedback.Name = "Feedback";
            this.Feedback.ReadOnly = true;
            this.Feedback.Size = new System.Drawing.Size(345, 332);
            this.Feedback.TabIndex = 22;
            this.Feedback.TextChanged += new System.EventHandler(this.Feedback_TextChanged);
            // 
            // lblfeed2
            // 
            this.lblfeed2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.lblfeed2.Location = new System.Drawing.Point(12, 263);
            this.lblfeed2.Name = "lblfeed2";
            this.lblfeed2.ReadOnly = true;
            this.lblfeed2.Size = new System.Drawing.Size(100, 19);
            this.lblfeed2.TabIndex = 23;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(466, 47);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(81, 20);
            this.label11.TabIndex = 24;
            this.label11.Text = "Instagram";
            this.label11.Click += new System.EventHandler(this.label11_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(466, 9);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(80, 20);
            this.label12.TabIndex = 25;
            this.label12.Text = "Cellphone";
            // 
            // txtcell
            // 
            this.txtcell.Location = new System.Drawing.Point(577, 6);
            this.txtcell.MaxLength = 10;
            this.txtcell.Name = "txtcell";
            this.txtcell.Size = new System.Drawing.Size(103, 26);
            this.txtcell.TabIndex = 26;
            this.txtcell.TextChanged += new System.EventHandler(this.txtcell_TextChanged);
            // 
            // txtUrl
            // 
            this.txtUrl.Location = new System.Drawing.Point(577, 47);
            this.txtUrl.Name = "txtUrl";
            this.txtUrl.Size = new System.Drawing.Size(103, 26);
            this.txtUrl.TabIndex = 27;
            // 
            // Form1
            // 
            this.AcceptButton = this.btnAdd;
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Inherit;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(830, 623);
            this.Controls.Add(this.txtUrl);
            this.Controls.Add(this.txtcell);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.lblfeed2);
            this.Controls.Add(this.Feedback);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.txtmname);
            this.Controls.Add(this.txtsrt1);
            this.Controls.Add(this.txtstate);
            this.Controls.Add(this.txtlname);
            this.Controls.Add(this.txtcity);
            this.Controls.Add(this.txtzip);
            this.Controls.Add(this.txtphone);
            this.Controls.Add(this.txtemail);
            this.Controls.Add(this.txtsrt2);
            this.Controls.Add(this.txtfname);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Person Details";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtfname;
        private System.Windows.Forms.TextBox txtsrt2;
        private System.Windows.Forms.TextBox txtemail;
        private System.Windows.Forms.TextBox txtphone;
        private System.Windows.Forms.TextBox txtzip;
        private System.Windows.Forms.TextBox txtcity;
        private System.Windows.Forms.TextBox txtlname;
        private System.Windows.Forms.TextBox txtstate;
        private System.Windows.Forms.TextBox txtsrt1;
        private System.Windows.Forms.TextBox txtmname;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.TextBox Feedback;
        private System.Windows.Forms.TextBox lblfeed2;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtcell;
        private System.Windows.Forms.TextBox txtUrl;
    }
}

