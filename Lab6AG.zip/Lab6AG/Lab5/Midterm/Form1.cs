﻿using Lab5;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Lab5_validation;
using System.Data.SqlClient;


namespace Lab5
{
    
    public partial class Form1:Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            PersonV2 temp = new PersonV2();

                
                temp.FirstName = txtfname.Text;
                temp.MiddleName = txtmname.Text;
                temp.LastName = txtlname.Text;
                temp.Street1 = txtsrt1.Text;
                temp.Street2 = txtsrt2.Text;
                temp.State = txtstate.Text;
                temp.City = txtcity.Text;
                temp.Zip = txtzip.Text;
                temp.Phone = txtphone.Text;   
                temp.Email = txtemail.Text;
                temp.Cell = txtcell.Text;
                temp.Instaurl = txtUrl.Text;
                


            if (!Feedback.Text.Contains("ERROR:"))
            {
                Feedback.Text = temp.AddARecord(); ;
            }
            else
            {
                /*temp.Feedback = ("Fullname: " + temp.FirstName + "  " + temp.MiddleName + "  " + temp.LastName + "\t" +
                                 "\nAddress: " + temp.Street1 + " \t" + temp.Street2 + " " + temp.City + " " + temp.State + "\t" +
                                 "\nPhone: " + temp.Phone + "\t" +
                                 "\nEmail: " + temp.Email+
                                 "\nCellphone:"+ temp.Cell+
                                 "\nInstagram URL:" +temp.Instaurl);*/
                Feedback.Text = temp.Feedback;
            }

        }

    private void btnView_Click(object sender, EventArgs e)
       {

       }

        private void txtfname_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnAdd_Click_1(object sender, EventArgs e)
        {
            PersonV2 temp = new PersonV2();


            temp.FirstName = txtfname.Text;
            temp.MiddleName = txtmname.Text;
            temp.LastName = txtlname.Text;
            temp.Street1 = txtsrt1.Text;
            temp.Street2 = txtsrt2.Text;
            temp.State = txtstate.Text;
            temp.City = txtcity.Text;
            temp.Zip = txtzip.Text;
            temp.Phone = txtphone.Text;
            temp.Email = txtemail.Text;
            temp.Cell = txtcell.Text;
            temp.Instaurl = txtUrl.Text;



            if (Feedback.Text.Contains("ERROR:"))
            {
                Feedback.Text = temp.AddARecord(); ;
            }
            else
            {
                /*temp.Feedback = ("Fullname: " + temp.FirstName + "  " + temp.MiddleName + "  " + temp.LastName + "\t" +
                                 "\nAddress: " + temp.Street1 + " \t" + temp.Street2 + " " + temp.City + " " + temp.State + "\t" +
                                 "\nPhone: " + temp.Phone + "\t" +
                                 "\nEmail: " + temp.Email+
                                 "\nCellphone:"+ temp.Cell+
                                 "\nInstagram URL:" +temp.Instaurl);*/
                Feedback.Text = temp.Feedback;
            }

        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void txtcell_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtphone_TextChanged(object sender, EventArgs e)
        {

        }

        private void insertbtn_Click(object sender, EventArgs e)
        {

         

        }

        private void Feedback_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
